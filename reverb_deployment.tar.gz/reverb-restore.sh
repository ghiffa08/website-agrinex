#!/usr/bin/env bash
# Bangun Reverb & .env untuk produksi di Hostinger

set -e

LARAVEL="/home/ghiffa/Documents/Projects_IoT/PlatformIO_Workspace/Projects/agrinex-smartdrip"
cd "$LARAVEL" || { echo "Error: tidak bisa cd $LARAVEL"; exit 1; }

echo "[$(date '+%F %T')] Mulai setup Reverb .env..."

# Cadangkan .env yang ada (jika ada)
[ -f .env ] && cp .env .env.bak.$(date +%s) && echo "-> .env .bak dibuat"

# (--overwrite) Tulis .env dengan .env production yang tepat
cat > .env <<'ENVEOF'
# Reverb & Vite untuk produksi di Hostinger
BROADCAST_CONNECTION=reverb

# Reverb Server (backend — listen lokal pada 127.0.0.1:8080, expose host domain)
REVERB_SERVER=smartdrip-system.agrinex.io
REVERB_SERVER_HOST=127.0.0.1
REVERB_SERVER_PORT=8080
REVERB_SERVER_PATH=

REVERB_HOST=smartdrip-system.agrinex.io
REVERB_PORT=443
REVERB_SCHEME=https

# App credentials (pertahankan yang ada saat ini)
REVERB_APP_ID=698663
REVERB_APP_KEY=tbsxrfwi1yg3to6isz1l
REVERB_APP_SECRET=y85kupchayzxsfs7obh8

# Variabel frontend (Vite) — ini yang membuat klien menembak ke wss yang benar
VITE_REVERB_APP_KEY="\${REVERB_APP_KEY}"
VITE_REVERB_HOST=smartdrip-system.agrinex.io
VITE_REVERB_PORT=443
VITE_REVERB_SCHEME=https
ENVEOF

echo "-> .env diperbarui"

# Bersihkan cache Laravel
php artisan config:clear
php artisan config:cache

# Bunuh server Reverb yang sedang berjalan (jika ada)
echo "-> Bunuh Reverb yang ada..."
pkill -f "php artisan reverb:start" || true

# Mulai Reverb di background, expose via 127.0.0.1:8080 -> Hostinger harus reverse proxy HTTPS + WSS
echo "-> Mulai Reverb (127.0.0.1:8080, hostname: smartdrip-system.agrinex.io)..."
nohup php artisan reverb:start --host=127.0.0.1 --port=8080 --hostname=smartdrip-system.agrinex.io --silent > reverb.log 2>&1 &
REVERB_PID=$!

echo "-> Reverb started, PID=$REVERB_PID"

# Build frontend (Vite)
echo "-> Jalankan npm run build..."
if command -v npm >/dev/null 2>&1; then
    npm run build
echo "-> Build Vite Selesai"
else
    echo "   (npm tidak ditemukan di PATH)"
fi

echo ""
echo "=== Resume .env production yang diatur ==="
cat .env

echo ""
echo "=== Proses Reverb yang sedang berjalan ==="
ps -f | grep "php artisan reverb:start" | grep -v grep

echo ""
echo "Log tail (reverb.log):"
tail -10 reverb.log 2>/dev/null || echo "(reverb.log tidak ada)"

echo ""
echo "=== Langkah-langkah berikut ==="
echo "1. Pastikan Hostinger reverse proxy HTTP/443 dari domain ke luar (looktsky) ke 127.0.0.1:8080"
echo "2. Konfigurasikan Nginx/Apache Hostinger untuk connect WS/WSS dari https://smartdrip-system.agrinex.io/"
echo "3. Buka aplikasi produksi front-end Anda. Konsol harus menembak ke wss://smartdrip-system.agrinex.io/app/..."

echo "[Selesai $(date '+%F %T')]"