#!/usr/bin/env bash
# Setup Reverb untuk Production Hostinger (smartdrip-system.agrinex.io)
# AMAN: Hanya update key Reverb/Vite yang relevan, pertahankan sisa .env

set -e

LARAVEL="/home/ghiffa/Documents/Projects_IoT/PlatformIO_Workspace/Projects/agrinex-smartdrip"
cd "$LARAVEL" || { echo "Error: tidak bisa cd $LARAVEL"; exit 1; }

echo "[$(date '+%F %T')] Setup Reverb production di $LARAVEL"
echo ""

# Backup .env
if [ -f .env ]; then
    BACKUP=".env.backup.$(date +%s)"
    cp .env "$BACKUP"
    echo "✓ Backup .env → $BACKUP"
fi

# Fungsi helper untuk set/update key di .env
set_env_key() {
    local key="$1"
    local value="$2"
    if grep -q "^${key}=" .env 2>/dev/null; then
        # Key ada, update
        sed -i "s|^${key}=.*|${key}=${value}|" .env
    else
        # Key tidak ada, append
        echo "${key}=${value}" >> .env
    fi
}

echo "→ Update .env keys untuk production..."

# Broadcast
set_env_key "BROADCAST_CONNECTION" "reverb"

# Reverb Server (backend)
set_env_key "REVERB_SERVER_HOST" "127.0.0.1"
set_env_key "REVERB_SERVER_PORT" "8080"
set_env_key "REVERB_HOST" "smartdrip-system.agrinex.io"
set_env_key "REVERB_PORT" "443"
set_env_key "REVERB_SCHEME" "https"

# VITE (frontend) — INI YANG KRUSIAL, harus hardcode domain production
set_env_key "VITE_REVERB_HOST" "smartdrip-system.agrinex.io"
set_env_key "VITE_REVERB_PORT" "443"
set_env_key "VITE_REVERB_SCHEME" "https"

# VITE_REVERB_APP_KEY tetap ambil dari REVERB_APP_KEY (preserve credentials)
# Cek apakah sudah pakai ${REVERB_APP_KEY} atau value hardcoded
if ! grep -q '^VITE_REVERB_APP_KEY="${REVERB_APP_KEY}"' .env 2>/dev/null; then
    # Ambil nilai REVERB_APP_KEY yang ada
    REVERB_KEY=$(grep '^REVERB_APP_KEY=' .env | cut -d= -f2)
    if [ -n "$REVERB_KEY" ]; then
        set_env_key "VITE_REVERB_APP_KEY" "\"$REVERB_KEY\""
    else
        set_env_key "VITE_REVERB_APP_KEY" '"\${REVERB_APP_KEY}"'
    fi
fi

echo "✓ .env updated"
echo ""

# Clear Laravel config cache
echo "→ Clear & cache config..."
php artisan config:clear
php artisan config:cache
echo "✓ Config cached"
echo ""

# Build Vite (inject VITE_* ke bundle)
echo "→ Build frontend (npm run build)..."
if command -v npm >/dev/null 2>&1; then
    npm run build
    echo "✓ Vite build selesai"
else
    echo "⚠ npm tidak ditemukan di PATH, skip build"
fi
echo ""

echo "=== .env keys terkait Reverb (setelah update) ==="
grep -E '^BROADCAST_CONNECTION|^REVERB_|^VITE_REVERB_' .env
echo ""

echo "=== Langkah selanjutnya di server Hostinger ==="
echo "1. Upload semua file (termasuk .env yang baru & public/build/*)"
echo "2. SSH ke Hostinger, cd ke root Laravel"
echo "3. Jalankan:"
echo "   php artisan config:clear && php artisan config:cache"
echo "4. Start Reverb (background):"
echo "   nohup php artisan reverb:start --host=127.0.0.1 --port=8080 --hostname=smartdrip-system.agrinex.io > storage/logs/reverb.log 2>&1 &"
echo "5. Setup Nginx reverse proxy untuk WebSocket (lihat file nginx-reverb.conf yang akan saya buatkan)"
echo ""
echo "[Selesai $(date '+%F %T')]"
